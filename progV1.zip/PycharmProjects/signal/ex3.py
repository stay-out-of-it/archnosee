import signal, time, datetime, os
import logging
import logging.config

logging.config.fileConfig('logging.conf')

# создаём logger
logger = logging.getLogger('simpleExample')

def dilenna(x):
    r = 1/x
    return r

dilenna(3)
dilenna(0)

logger.debug('debug message')
logger.info('info message')
logger.warn('warn message')
logger.error('error message')
logger.critical('critical message')


