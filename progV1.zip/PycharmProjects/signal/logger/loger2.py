import logging
import sys

logger = logging.getLogger(str(sys.argv[0]))
logging.basicConfig(level=logging.DEBUG)

handler = logging.FileHandler('hello.log')
handler.setLevel(logging.DEBUG)
formatter = logging.Formatter('%(asctime)s: %(name)s: %(levelname)s - %(message)s')
handler.setFormatter(formatter)


logger.info('Start reading database')
# read database here
records = {'john': 55, 'tom': 66}
logger.debug('Records: %s', records)
logger.info('Updating records ...')
# update records here

logger.addHandler(handler)
logger.info('Finish updating records')

