import json
import logging
import time
import sys

from functools import reduce
from daemon3 import Daemon

'''
json_file = {
    "protocol": "icmp",
    "sourceIp": "192.15.24.24",
    "sourcePort": 0,
    "destinationIp": "192.155.24.23",
    "destinationPort": 0,
    "msg": "icmp",
    "additionalOptions": [
        {
            "sid": 1000001
        }
    ]
}'''

logging.basicConfig (
    level=logging.DEBUG,
    filename="test.log",
    format="%(asctime)s: %(message)s"
)

with open ('json_file_ex.json') as json_file_1:
    json_file_1 = json.load (json_file_1)


'''
def parser(json_file=json_file_1):
    return (
        'alert ' + json_file["protocol"] + " " + json_file["sourceIp"] + " " + str(json_file["sourcePort"]) + " -> "
        + json_file["destinationIp"] + " " + str(json_file["destinationPort"])
        + r' (msg:"' + json_file["msg"] + r'"; sid:"' + str(json_file['additionalOptions'][0]['sid']) + r'";)')
'''


def key0 ():
    list0 = []
    for key in json_file_1['additionalOptions'][0].keys ():
        list0.append (key)
    return list0


l = []
for n in range (len (json_file_1['additionalOptions'][0])):
    l.append (n)


map_list = list (map (
    lambda m: r' {}:"'.format (str (key0 ()[m])) + str (json_file_1['additionalOptions'][0][str (key0 ()[m])]) + r'";',
    l))
reduce_all = reduce (lambda x, y: str (x) + str (y), map_list)


def parser ():
    return (
        'alert ' + json_file_1["protocol"] + " " + json_file_1["sourceIp"] + " " + str (
            json_file_1["sourcePort"]) + " -> "
        + json_file_1["destinationIp"] + " " + str (json_file_1["destinationPort"])
        + r' (msg:"' + json_file_1["msg"] + r'";' + reduce_all + ')'
    )


'''
def runing(n=0):
    while True:
        if n == 3:
            break
        n += 1
        logging.debug(parser())
        time.sleep(1)
'''


class MyDaemon (Daemon):
    def run (self):
        while True:
            logging.debug (parser ())
            time.sleep (1)


if __name__ == "__main__":
    daemon = MyDaemon ('/tmp/daem.pid')
    if len (sys.argv) == 2:
        if 'start' == sys.argv[1]:
            daemon.start ()
        elif 'stop' == sys.argv[1]:
            daemon.stop ()
        elif 'restart' == sys.argv[1]:
            daemon.restart ()
        else:
            print ("Unknown command")
            sys.exit (2)
        sys.exit (0)
    else:
        print ("usage: %s start|stop|restart" % sys.argv[0])
        sys.exit (2)
