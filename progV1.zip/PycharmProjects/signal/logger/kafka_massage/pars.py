from functools import reduce

s= {' "destinationPort"': ' 0',
    'additionalOptions': {'gid': '1000002',
                          'sid': '1000001',
                          'pid': '1000002',
                          'rid': '1000002'},
    ' "sourcePort"': ' 0',
    ' "protocol"': ' "icmp"',
    ' "destinationIp"': ' "192.155.24.23"',
    ' "msg"': ' "icmp"',
    ' "sourceIp"': ' "192.15.24.24"'}




string=str(r'''ConsumerRecord(topic="my-topic2", partition=0, offset=0, timestamp=1509546108302, timestamp_type=0, key=None, value=b'{"additionalOptions": [{"sid": 1000001, "gid": 1000002, "pid": 1000002, "rid": 1000002}], "destinationIp": "192.155.24.23", "msg": "icmp", "sourceIp": "192.15.24.24", "sourcePort": 0, "destinationPort": 0, "protocol": "icmp"}', checksum=-598243456, serialized_key_size=-1, serialized_value_size=225)''')

l=string.split('=')[7]
m= l.split("'")[1]
r=m.split("[")
addit_op=r[1].split("]")[0]
addit_op_1=addit_op.split(",")
add_all=r[1].split("]")[1].split(',')

json_file_1={}
for n in range(1,len(r[1].split("]")[1].split(','))):
    if r[1].split ("]")[1].split (',')[n].split (":")[0].split("}")[0].split('"')[1]=='destinationPort' or r[1].split ("]")[1].split (',')[n].split (":")[0].split("}")[0].split('"')[1]=='sourcePort':
        json_file_1[r[1].split ("]")[1].split (',')[n].split (":")[0].split("}")[0].split('"')[1]]=int(r[1].split ("]")[1].split (',')[n].split (":")[1].split("}")[0])
    else:
        json_file_1[r[1].split ("]")[1].split (',')[n].split (":")[0].split ("}")[0].split ('"')[1]] = r[1].split ("]")[1].split (',')[n].split (":")[1].split ("}")[0]


dict1={}
for n in range(len(addit_op_1)):
    dict1['{}'.format (addit_op_1[n].split ('"')[1]).split("}")[0]]= '{}'.format (addit_op_1[n].split ('"')[2].split ()[1].split("}")[0])


json_file_1["additionalOptions"]=dict1



print(json_file_1)
print(r[1].split ("]")[1].split (',')[n].split (":")[0].split("}")[0])


