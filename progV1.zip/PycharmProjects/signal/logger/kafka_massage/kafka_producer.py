import json
import threading

from kafka import KafkaProducer


class Producer (threading.Thread):
    def __init__ (self):
        threading.Thread.__init__ (self)
        self.stop_event = threading.Event ()

    def stop (self):
        self.stop_event.set ()

    def run (self):
        producer = KafkaProducer (bootstrap_servers='192.168.20.123:9092',
                                  value_serializer=lambda v: json.dumps (v).encode ('utf-8'))

        producer.send ('my-topic2', {
            "protocol": "icmp",
            "sourceIp": "192.15.24.24",
            "sourcePort": 0,
            "destinationIp": "192.155.24.23",
            "destinationPort": 0,
            "msg": "icmp",
            "additionalOptions": [
                {
                    "sid": 1000001,
                    "pid": 1000002,
                    "gid": 1000002,
                    "rid": 1000002
                }
            ]
        })

        producer.close ()