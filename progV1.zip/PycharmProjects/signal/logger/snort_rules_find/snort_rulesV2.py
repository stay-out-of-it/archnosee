import re


file = open ("local.rules", "r")
lis = file.read ()
file.close ()
file = open ("local.rules", "r")
l=[]
for line in file.readlines ():
    if len (line.split ('{}'.format (str ('sid: 1000000')))) > 1:
        l.append(line)

file.close()


fin = open ("input", "r")
fin2 = fin.readline ().split("\n")[0]
fout = open ("local.rules", "w")
fout.write (re.sub (r'# alert tcp $HOME_NET any', fin2, lis, re.I))
fin.close ()
fout.close ()


print(lis)


