import fileinput
import re

text1 = open ('input', 'r')
text = text1.readline ()
text_list = text1.readlines ()





def find_sid (text):
    sid_new = text.split ('sid:')[1].split (';')[0]
    file = open ("local.rules", "r")
    for line in file.readlines ():
        if len (line.split ('{}'.format (str ('sid:' + sid_new)))) > 1:
            if line[0] == "#":
                up_string = "# " + str (text)
            else:
                up_string = str (text)




            if text_list[0].split ("\n")[0] == 'update':
                print (line)
                print (up_string)



if __name__ == '__main__':
    find_sid(text)

