import fileinput


fin = open ("input", "r")

fin2 = fin.readline ().split ("\n")[0]
files =fin.readlines()[1]

fin.close()


file = open (files, "r")
lis = file.read ()
file.close ()

file = open (files, "r")


sid_new = fin2.split ('sid:')[1].split (';')[0]


l = []

for line in file.readlines ():
    if len (line.split ('{}'.format (('sid:' + str(sid_new))))) > 1:
        l.append (line)

print(l!=[])

try:
    if l[0][0] == "#":
        fin2 = "# " + str (fin2)
    for lined in fileinput.input (files, inplace=0):
        if l==[]:
            print (lined.replace (l[0], fin2).split ("\n")[0])
        else:
            print("-")
except IndexError:
    None


