import json
import logging
import time
from daemon3 import Daemon

'''
json_file = {
    "protocol": "icmp",
    "sourceIp": "192.15.24.24",
    "sourcePort": 0,
    "destinationIp": "192.155.24.23",
    "destinationPort": 0,
    "msg": "icmp",
    "additionalOptions": [
        {
            "sid": 1000001
        }
    ]
}'''


logging.basicConfig(filename="/home/BeIntern/PycharmProjects/signal/logger/EXLOG/log_and_pars/test.log",
                    level=logging.DEBUG,
                    format="%(asctime)s: %(message)s")

with open('/home/BeIntern/PycharmProjects/signal/logger/EXLOG/log_and_pars/json_file_ex.json') as json_file_1:
    json_file_1 = json.load(json_file_1)


def parser(json_file=json_file_1):
    return (
        'alert ' + json_file["protocol"] + " " + json_file["sourceIp"] + " " + str(json_file["sourcePort"]) + " -> "
        + json_file["destinationIp"] + " " + str(json_file["destinationPort"])
        + r' (msg:"' + json_file["msg"] + r'"; sid:"' + str(json_file['additionalOptions'][0]['sid']) + r'";)')


def run(n=0):
    while True:
        if n == 3:
            break
        n += 1
        logging.debug(parser())
        time.sleep(1)


run()


class MyDaemon():
    def run(self):
        while True:
            time.sleep(1)