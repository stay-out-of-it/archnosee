import json
from functools import reduce

with open ('json_file_ex.json') as json_file:
    json_file = json.load (json_file)


def key0 ():
    list0 = []
    for key in json_file['additionalOptions'][0].keys ():
        list0.append (key)
    return list0




l = []
for n in range(len(json_file['additionalOptions'][0])):
    l.append(n)


map_list=list(map(lambda l: r' {}:"'.format (str (key0 ()[l])) + str (json_file['additionalOptions'][0][str (key0 ()[l])]) + r'";', l))
reduce_all=reduce(lambda x,y: str(x)+str(y), map_list)



def parser ():
    return (
        'alert ' + json_file["protocol"] + " " + json_file["sourceIp"] + " " + str (json_file["sourcePort"]) + " -> "
        + json_file["destinationIp"] + " " + str (json_file["destinationPort"])
        + r' (msg:"' + json_file["msg"] + r'";' + reduce_all + ')')
