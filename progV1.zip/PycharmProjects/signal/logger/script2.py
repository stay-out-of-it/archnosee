#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging



def somefunc ():
    logger = logging.getLogger(__name__)

    logger.info('Started script 2')
