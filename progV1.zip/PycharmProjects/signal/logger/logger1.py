#!/usr/bin/env python
# -*- coding: utf-8 -*-

import logging

from logger import script2

logging.basicConfig(filename='logger.log', level=logging.INFO, format='%(asctime)s %(name)-12s %(levelname)-8s %(message)s')

if __name__ == '__main__':
    logger = logging.getLogger(__name__)
    logger.info('Started script 1')
    script2.somefunc()
    logger.info('Finished script 1')
