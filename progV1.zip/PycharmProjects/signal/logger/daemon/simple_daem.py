import daemon, time, logging


def test():
    log = open('liveblog.log')
    d = daemon.DaemonContext(stdout=log, stderr=log)
    d.open()

    while True:
        logging.info("Time %s" % time.time())
        time.sleep(1)


test()