import sys
import logging


logging.basicConfig(filename="test.log",
                    level=logging.DEBUG,
                    format="%(asctime)s: %(message)s")


logging.debug("This is the name of the script: " + str(sys.argv[0]))
logging.debug("Number of arguments: " + str(len(sys.argv)))
logging.debug("The arguments are: " + str(sys.argv[0]))