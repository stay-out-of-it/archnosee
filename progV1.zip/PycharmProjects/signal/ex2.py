import signal, time, datetime


class Signal_handler(object):
    """ Класс обрабатывающий системные сигналы """

    def __init__(self, target):
        """target - экземпляр класса"""
        self.target = target

    def handle_sigalarm(self, signum, frame):
        self.target.process_alarm_signal()


class Foo(object):
    def __init__(self, *args, **kwargs):
        # Регистрируем обработчики сигналов
        sh = Signal_handler(self)
        signal.signal(signal.SIGALRM, sh.handle_sigalarm)
        # Устанавливаем таймер
        signal.setitimer(signal.ITIMER_REAL, 3, 3)

    def process_alarm_signal(self):
        print('{} - alarm_checking'.format(datetime.datetime.now()))
        if (datetime.datetime.now() - self.datetime_mark).seconds >= 10:
            # устанавливаем переменную для выхода из цикла
            self.need_break = True
            # отключаем таймер
            signal.setitimer(signal.ITIMER_REAL, 0)

    def run(self):
        self.need_break = False
        self.datetime_mark = datetime.datetime.now()
        print('{} - Run'.format(datetime.datetime.now()))
        while not self.need_break:
            # симуляция работы
            time.sleep(1)


if __name__ == '__main__':
    foo = Foo()
    foo.run()