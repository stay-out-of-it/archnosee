import signal, sys, time


def handle(signum, frame):
    print('Alarm! job failed')
    sys.exit(1)


def job(n):
    data = []
    for x in range(n):
        data.append(x ** 2)
        time.sleep(0.1)


signal.signal(signal.SIGALRM, handle)

# Имитация простой работы, которая будет выполнена успешно
signal.alarm(3)
job(10)
print('Job 1 done')
signal.alarm(0)

# Имитация объемной работы, которая не будет успешно выполнена
signal.alarm(3)
job(100)
print('Job 2 done')
signal.alarm(0)