import time
import daemon

class App():
    def __init__(self):
        self.stdin_path = '/dev/null'
        self.stdout_path = '~/deamon'
        self.stderr_path = '~/deamon'
        self.pidfile_path = ''
        self.pidfile_timeout = 5
    def run(self):
        while True:
            print("Howdy!  Gig'em!  Whoop!")
            time.sleep(10)

app = App()
daemon_runner = daemon.DaemonContext(app)
daemon_runner.do_action()
print(open('~/deamon'))