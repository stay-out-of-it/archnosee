import json

# строка которую будем парсить

json_string = json.load('json_file_ex.json'"read")


# распарсенная строка
# parsed_string = json.loads(json_string)
# print(parsed_string)

print(json_string)