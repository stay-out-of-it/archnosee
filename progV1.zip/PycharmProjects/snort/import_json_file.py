import json


with open('json_file_ex.json') as data_file:
    data = json.load(data_file)

print(data)