import json

'''
json_file = {
   "protocol":"icmp",
   "sourceIp":"192.15.24.24",
   "sourcePort":0,
   "destinationIp":"192.155.24.23",
   "destinationPort":0,
   "msg":"icmp",
   "additionalOptions":[
      {
         "sid":1000001
      }
   ]
}
'''

with open('json_file_ex.json') as json_file:
    json_file = json.load(json_file)

def parser():
    return ('alert ' + json_file["protocol"] + " " + json_file["sourceIp"] + " " + str(json_file["sourcePort"]) + " -> " +
          json_file["destinationIp"] + " " + str(json_file["destinationPort"]) + r' (msg:"' + json_file["msg"] + r'"; sid:"' + str(json_file['additionalOptions'][0]['sid']) + r'";)' )

print(parser())